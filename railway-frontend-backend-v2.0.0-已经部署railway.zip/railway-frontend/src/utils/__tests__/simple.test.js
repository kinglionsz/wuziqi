// Simple test to verify vitest works
describe('simple test', () => {
  it('should pass', () => {
    expect(1 + 1).toBe(2)
  })
})
